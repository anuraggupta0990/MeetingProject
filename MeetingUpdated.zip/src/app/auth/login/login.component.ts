import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { ApiService } from '../services/api.service';
import { Router } from '@angular/router';
// import { ToastrService } from 'ngx-toastr';
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';


export interface AuthenticationResult {
  IsSuccessful: boolean;
  Token?: string;
  IsAccountActivated: boolean;
}


export function passwordComplexityValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const value = control.value || '';
    if (!/[A-Z]/.test(value)) {
      return { hasUpperCase: true };
    }
    if (!/[a-z]/.test(value)) {
      return { hasLowerCase: true };
    }
    if (!/\d/.test(value)) {
      return { hasNumber: true };
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(value)) {
      return { hasSpecialCharacter: true };
    }
    if (/\s/.test(value)) {
      return { hasSpace: true };
    }
    return null;
  };
}
export function emailValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {

    const emailRegex = /^[a-zA-Z][a-zA-Z0-9._%+-]*@[a-zA-Z0-9.-]+\.(com|in|net|org|edu|gov|mil|biz|info|io|co)$/;


    if (control.value === '') {
      return null; 
    }

  
    if (!emailRegex.test(control.value)) {
      return { email: true };
    }

    return null;
  };
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {
hide: boolean=true;
loginForm: FormGroup;

  constructor(private fb: FormBuilder,private router: Router, 
    // private apiService: ApiService, private toast:ToastrService
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required,emailValidator()]],
      password: ['', [Validators.required, Validators.minLength(8), passwordComplexityValidator()]]
    });
  }

  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }



  togglePasswordVisibility(): void {
    this.hide = !this.hide;
  }


  // onSubmit(): void {
  //   if (this.loginForm.valid) {
  //     const formData = this.loginForm.value;

  //     this.apiService.createPost(formData).subscribe(response => {
  //       if (response) {
  //         localStorage.setItem('token',response.user);
  //         this.router.navigate(["/user/getuser"]);
  //         // console.log('API Response:', response);
  //         this.toast.success("Login successfully")
  //       }
  //       })
  // }

  // onSubmit(): void {
  //   if (this.loginForm.valid) {
  //     const formData = this.loginForm.value;
  
  //     this.apiService.createPost(formData).subscribe(
  //       (response: any) => {
  //         console.log('API Response:', response); // Log response to inspect structure
  
  //         if (response.IsSuccessful) {
  //           if (response.token) {
  //             localStorage.setItem('token', response.token);
  //           }
  //           this.router.navigate(["/user/getuser"]);
  //           this.toast.success("Login successful");
  //           this.loginForm.reset();
  //         } else if (!response.IsAccountActivated) {
  //           this.toast.error("Account not activated. Please check your email for activation instructions.");
  //         } else {
  //           this.toast.error("Invalid credentials.");
  //         }
  //       },
  //       error => {
  //         this.toast.error("An error occurred while logging in. Please try again.");
  //       }
  //     );
  //   }
  // }

  onSubmit(): void {
    // if (this.loginForm.valid) {
    //   const formData = this.loginForm.value;
    //   this.apiService.createPost(formData).subscribe({
    //     next: response => {
    //       if (response.success) {
    //         localStorage.setItem('token', response.token);
    //         this.router.navigate(['/user/getuser']);
    //         this.toast.success("Login successful");
    //       } else {
    //         // This block should never be reached if the backend correctly sets success to true only on success.
    //         this.toast.error(response.message);
    //       }
    //     },
    //     error: err => {
    //       if (err.status === 401) {
    //         this.toast.error("Invalid credentials.");
    //       } else if (err.status === 404) {
    //         this.toast.error("User does not exist.");
    //       } else if (err.status === 400) {
    //         this.toast.error("Your account is not active. Please check your email for an activation link.");
    //       } else {
    //         this.toast.error("An error occurred during login.");
    //       }
    //     }
    //   });
      
    // }
  }
  
  

}


