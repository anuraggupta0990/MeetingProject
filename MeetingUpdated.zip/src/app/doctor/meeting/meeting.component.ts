import { Component } from '@angular/core';
import { ZoomMtg } from '@zoom/meetingsdk';

ZoomMtg.setZoomJSLib('https://source.zoom.us/3.6.0/lib', '/av'); // Replace {VERSION} with the specific version you're using
ZoomMtg.preLoadWasm();
ZoomMtg.prepareWebSDK();

@Component({
  selector: 'app-meeting',
  templateUrl: './meeting.component.html',
  styleUrls: ['./meeting.component.css']
})
export class MeetingComponent {

}
